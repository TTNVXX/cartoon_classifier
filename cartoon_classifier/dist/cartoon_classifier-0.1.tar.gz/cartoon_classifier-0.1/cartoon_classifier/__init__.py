# cartoon_classifier/__init__.py

from .classifier import CartoonClassifier
